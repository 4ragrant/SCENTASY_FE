import React from "react";
import ChatUI from "./ChatUI";

const ChatPage = () => {
  return (
    <div>
      <ChatUI />
    </div>
  );
};

export default ChatPage;